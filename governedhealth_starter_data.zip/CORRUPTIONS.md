# Known Corruptions in data/corrupted/

This file documents the deliberate corruptions injected into the records
in `data/corrupted/`. Each record has exactly one corruption type (or is
a clean control). The Data Quality agent must catch each non-control
corruption type. This file is the ground truth for evaluation.

## Dataset structure

- `data/synthea/full/` - 1,000 clean Synthea-format records (used by
  Analytics agent for cohort construction)
- `data/synthea/sample/` - first 50 records from full/, copied here for
  faster iteration during development
- `data/corrupted/` - the 50 sample records with deliberate corruptions
  applied (this file describes which)

Seed: 42
Generated: 2026-05-28

## Corruption types

- **missing_birthDate**: the Patient resource has no birthDate field. The
  Data Quality agent must flag this as a completeness failure.
- **bad_date**: the Patient resource has birthDate = '1850-13-45' (invalid
  ISO date and impossible year). The Data Quality agent must flag this as
  a validity failure.
- **invalid_snomed_code**: at least one Condition resource has a SNOMED
  code of 'FAKE-999' which does not exist. The Data Quality agent must
  flag this as a vocabulary failure.
- **clean_control**: the record was copied from the clean sample with no
  changes. The Data Quality agent must NOT flag these (false positive check).

## Record-by-record manifest

| File | Corruption type |
|------|-----------------|
| Abigail119_Cote_b9c037aa.json | missing_birthDate |
| Abigail142_Patel_9cf023dd.json | bad_date |
| Abigail172_OBrien_ef5eeca5.json | invalid_snomed_code |
| Abigail1_Clark_b2b9437a.json | clean_control |
| Abigail206_Khan_e07309de.json | missing_birthDate |
| Abigail355_Wright_11bb797a.json | bad_date |
| Abigail408_Bouchard_b2a43bf4.json | invalid_snomed_code |
| Abigail414_Kumar_b1012b0f.json | clean_control |
| Abigail453_Kumar_b89b9722.json | missing_birthDate |
| Abigail523_Khan_8b0409e4.json | bad_date |
| Abigail582_Murphy_ffc9ff30.json | invalid_snomed_code |
| Abigail595_Clark_f728a97a.json | clean_control |
| Abigail690_Patel_99032fa5.json | missing_birthDate |
| Abigail709_Singh_88da0ce1.json | bad_date |
| Abigail755_Bouchard_653ac312.json | invalid_snomed_code |
| Abigail766_Liu_517c8165.json | clean_control |
| Abigail77_Kumar_d40e53ce.json | missing_birthDate |
| Abigail789_Bouchard_875a3a92.json | bad_date |
| Abigail794_Bell_e12587f7.json | invalid_snomed_code |
| Abigail870_Gagnon_cd18ffcd.json | clean_control |
| Abigail884_Smith_4167e905.json | missing_birthDate |
| Abigail886_Walker_023702d6.json | bad_date |
| Aiden113_Murphy_9db94eee.json | invalid_snomed_code |
| Aiden151_Smith_e12ff6cd.json | clean_control |
| Aiden169_OBrien_acdfe0ff.json | missing_birthDate |
| Aiden195_Chen_a4f0708a.json | bad_date |
| Aiden238_Liu_09b4413c.json | invalid_snomed_code |
| Aiden249_Murphy_37d7cab3.json | clean_control |
| Aiden303_Lee_39ba243a.json | missing_birthDate |
| Aiden31_Patel_0d6a05b3.json | bad_date |
| Aiden346_Brown_be3c7c84.json | invalid_snomed_code |
| Aiden441_Tremblay_3b195b02.json | clean_control |
| Aiden447_Scott_9b354089.json | missing_birthDate |
| Aiden519_Lee_5656b5f9.json | bad_date |
| Aiden577_Liu_d2316495.json | invalid_snomed_code |
| Aiden63_Scott_bdd151b0.json | clean_control |
| Aiden662_Kumar_28d1f460.json | missing_birthDate |
| Aiden680_Tremblay_64bf4bff.json | bad_date |
| Aiden896_Walker_17709a00.json | invalid_snomed_code |
| Aiden927_Tremblay_f9f146b0.json | clean_control |
| Aiden939_Wang_69d1ae79.json | missing_birthDate |
| Alexander146_Wang_61eaaa65.json | bad_date |
| Alexander215_Walker_6bf843df.json | invalid_snomed_code |
| Alexander217_Patel_16f1e5cb.json | clean_control |
| Alexander329_Clark_bf3025c3.json | missing_birthDate |
| Alexander460_Scott_ce9ca015.json | bad_date |
| Alexander461_Smith_8fa7bdec.json | invalid_snomed_code |
| Alexander472_Scott_cd68f11c.json | clean_control |
| Alexander546_Murphy_5905fd87.json | missing_birthDate |
| Alexander605_Wright_6dd5346e.json | bad_date |